package com.InnovaSoft.InnovaSoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnovaSoftApplicationTests {

	@Test
	void contextLoads() {
	}

}
